const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const authenticateToken = require('../middleware/auth');
const { pool } = require('../config/db');

/**
 * @route   GET /api/health
 * @desc    Get API health status and check database connectivity
 * @access  Public
 */
router.get('/health', async (req, res) => {
  try {
    // Run a quick query to verify DB is reachable and responding
    const startTime = Date.now();
    const [rows] = await pool.query('SELECT 1 + 1 AS solution');
    const responseTimeMs = Date.now() - startTime;
    
    res.json({
      status: 'UP',
      uptime: process.uptime(),
      database: {
        status: 'CONNECTED',
        responseTimeMs,
        check: rows[0].solution === 2 ? 'OK' : 'FAIL'
      },
      timestamp: new Date()
    });
  } catch (error) {
    res.status(500).json({
      status: 'DOWN',
      uptime: process.uptime(),
      database: {
        status: 'DISCONNECTED',
        error: error.message
      },
      timestamp: new Date()
    });
  }
});

/**
 * @route   GET /api/tables
 * @desc    Retrieve all tables in the connected database (to inspect structure)
 * @access  Private (JWT Token Required)
 */
router.get('/tables', authenticateToken, async (req, res) => {
  try {
    const dbName = process.env.DB_NAME || 'u156958239_moil_hr_app';
    const query = `
      SELECT TABLE_NAME AS name, TABLE_ROWS AS row_count
      FROM information_schema.tables 
      WHERE table_schema = ?
    `;
    const [rows] = await pool.query(query, [dbName]);
    
    res.json({
      database: dbName,
      tableCount: rows.length,
      tables: rows
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to retrieve tables metadata',
      message: error.message
    });
  }
});

/**
 * @route   GET /api/data/:table
 * @desc    Retrieve all rows from a specific table (limit 100)
 * @access  Private (JWT Token Required)
 */
router.get('/data/:table', authenticateToken, async (req, res) => {
  const tableName = req.params.table;
  
  // Basic validation: only allow alphanumeric characters and underscores in table name
  if (!/^[a-zA-Z0-9_]+$/.test(tableName)) {
    return res.status(400).json({ error: 'Invalid table name format' });
  }

  try {
    const [rows] = await pool.query(`SELECT * FROM \`${tableName}\` LIMIT 100`);
    res.json({
      table: tableName,
      count: rows.length,
      data: rows
    });
  } catch (error) {
    res.status(500).json({
      error: `Failed to retrieve data from table "${tableName}"`,
      message: error.message
    });
  }
});

/**
 * @route   POST /api/login
 * @desc    Authenticate employee by employee number (User ID) and PAN number (Password), returning a JWT token
 * @access  Public
 */
router.post('/login', async (req, res) => {
  const { employee_number, password } = req.body;

  if (!employee_number || !password) {
    return res.status(400).json({ error: 'Employee number and password are required' });
  }

  try {
    // 1. Fetch employee details from manpower table, joined with agents table to get reporting officers
    const empQuery = `
      SELECT m.*, a.reporting_officer, a.reporting_officer_1 
      FROM manpower m 
      LEFT JOIN zhcm_lr_t_agents_03072026 a ON m.employee_number = a.personnel_number 
      WHERE m.employee_number = ?
    `;
    const [empRows] = await pool.query(empQuery, [employee_number]);
    
    if (empRows.length === 0) {
      return res.status(401).json({ error: 'Invalid Employee Number or Password' });
    }
    
    const employee = empRows[0];

    // 2. Check if a custom password exists in the user_accounts table
    const credQuery = `SELECT password FROM user_accounts WHERE employee_number = ?`;
    const [credRows] = await pool.query(credQuery, [employee_number]);
    
    let isPasswordValid = false;
    let hasCustomPassword = false;

    if (credRows.length > 0) {
      // User has custom password, verify against it
      isPasswordValid = credRows[0].password === password;
      hasCustomPassword = true;
    } else {
      // Fall back to verifying against PAN card number (default password)
      if (employee.pan_number) {
        isPasswordValid = employee.pan_number.toString().trim().toUpperCase() === password.toString().trim().toUpperCase();
      }
    }

    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid Employee Number or Password' });
    }

    // Sign JWT token
    const tokenSecret = process.env.JWT_SECRET || 'fallback_secret';
    const payload = {
      employee_number: employee.employee_number,
      employee_name: employee.employee_name,
      department: employee.department,
      position: employee.position_name
    };
    
    const token = jwt.sign(payload, tokenSecret, { expiresIn: '24h' });

    res.json({
      message: 'Login successful',
      token,
      must_change_password: !hasCustomPassword,
      employee: {
        id: employee.id,
        employee_number: employee.employee_number,
        name: employee.employee_name,
        status: employee.employment_status,
        group: employee.employee_group,
        subgroup: employee.employee_subgroup_text,
        department: employee.department,
        position: employee.position_name,
        gender: employee.gender,
        email: employee.email_id,
        mobile: employee.mobile_number,
        pan_number: employee.pan_number,
        has_custom_password: hasCustomPassword,
        must_change_password: !hasCustomPassword,
        reporting_officer: employee.reporting_officer || '0',
        reporting_officer_1: employee.reporting_officer_1 || '0'
      }
    });
  } catch (error) {
    console.error('[Login Error]', error.message);
    res.status(500).json({
      error: 'Authentication failed',
      message: error.message
    });
  }
});

/**
 * @route   POST /api/change-password
 * @desc    Change password for the logged-in employee
 * @access  Private (JWT Token Required)
 */
router.post('/change-password', authenticateToken, async (req, res) => {
  const { old_password, new_password } = req.body;
  const employee_number = req.user.employee_number;

  if (!old_password || !new_password) {
    return res.status(400).json({ error: 'Old password and new password are required' });
  }

  try {
    // 1. Fetch employee details from manpower table
    const empQuery = `SELECT * FROM manpower WHERE employee_number = ?`;
    const [empRows] = await pool.query(empQuery, [employee_number]);
    
    if (empRows.length === 0) {
      return res.status(404).json({ error: 'Employee record not found' });
    }

    const employee = empRows[0];

    // 2. Fetch current password from user_accounts table if exists
    const credQuery = `SELECT password FROM user_accounts WHERE employee_number = ?`;
    const [credRows] = await pool.query(credQuery, [employee_number]);

    let isOldPasswordValid = false;
    if (credRows.length > 0) {
      isOldPasswordValid = credRows[0].password === old_password;
    } else if (employee.pan_number) {
      isOldPasswordValid = employee.pan_number.toString().trim().toUpperCase() === old_password.toString().trim().toUpperCase();
    }

    if (!isOldPasswordValid) {
      return res.status(401).json({ error: 'Invalid current password' });
    }

    // 3. Save/Update new password in user_accounts table using UPSERT
    const upsertQuery = `
      INSERT INTO user_accounts (employee_number, password) 
      VALUES (?, ?) 
      ON DUPLICATE KEY UPDATE password = ?
    `;
    await pool.query(upsertQuery, [employee_number, new_password, new_password]);

    res.json({
      message: 'Password changed successfully'
    });
  } catch (error) {
    console.error('[Change Password Error]', error.message);
    res.status(500).json({
      error: 'Failed to change password',
      message: error.message
    });
  }
});

// ==========================================
// Helper Mappers for SAP <=> Flutter Formats
// ==========================================

function mapAbsenceType(code) {
  const cleanCode = (code || '').toString().trim();
  const types = {
    // Database quota types (absence_quota_type)
    '1': 'Earned leave',
    '2': 'Casual Leave',
    '3': 'HPL',
    '5': 'Optional Holiday',
    
    // SAP subtype codes
    '1000': 'Casual Leave',
    '1001': 'Earned leave',
    '1002': 'HPL',
    '1003': 'Optional Holiday',
    '1004': 'Official Tour',
    '1010': 'Commuted Leave',
    '1012': 'Maternity Leave',
    '1013': 'Paternity Leave',
    '1019': 'Special Casual Leave',
    '1020': 'Study Leave',
    '1032': 'Child Care Leave'
  };
  return types[cleanCode] || 'Other Leave';
}

function reverseMapAbsenceType(name) {
  const codes = {
    'Casual Leave': '1000',
    'Earned leave': '1001',
    'HPL': '1002',
    'Optional Holiday': '1003',
    'Official Tour': '1004'
  };
  return codes[name] || '1000';
}

// ==========================================
// Leave Management APIs
// ==========================================

/**
 * @route   GET /api/leaves
 * @desc    Fetch leave requests for an employee
 * @access  Private (JWT Token Required)
 */
router.get('/leaves', authenticateToken, async (req, res) => {
  const employeeId = req.query.employee_id || req.user.employee_number;
  try {
    const query = `SELECT * FROM absence WHERE personnel_number = ? ORDER BY start_date DESC`;
    const [rows] = await pool.query(query, [employeeId]);
    
    const leaves = rows.map(row => {
      const duration = row.full_day === 'X' ? 'Full-Day' : 'Half-Day';
      let status = 'Approved';
      if (row.lock_indicator === 'P') status = 'Pending';
      else if (row.lock_indicator === 'R') status = 'Rejected';
      else if (row.lock_indicator === 'A') status = 'Approved';

      return {
        id: row.id.toString(),
        employeeId: row.personnel_number,
        leaveType: mapAbsenceType(row.att_absence_type),
        startDate: row.start_date,
        startTime: row.start_time || '00:00:00',
        endDate: row.end_date,
        endTime: row.end_time || '00:00:00',
        duration,
        processor: row.changed_by,
        status,
        absenceHours: parseFloat(row.absence_hours || 0),
        used: `${row.att_abs_days || 0}.00 Days`,
        reason: row.desc_of_illness || row.reason_for_change || 'No reason provided',
        remarks: row.desc_of_illness_2,
        appliedOn: row.changed_on || row.start_date,
        approvedOn: row.confirmed_on ? new Date(row.confirmed_on) : null
      };
    });

    res.json(leaves);
  } catch (error) {
    console.error('[Get Leaves Error]', error.message);
    res.status(500).json({ error: 'Failed to fetch leave requests', message: error.message });
  }
});

/**
 * @route   POST /api/leaves
 * @desc    Submit a new leave application
 * @access  Private (JWT Token Required)
 */
router.post('/leaves', authenticateToken, async (req, res) => {
  const { leave_type, start_date, end_date, start_time, end_time, duration, absence_hours, reason } = req.body;
  const employeeId = req.user.employee_number;

  if (!leave_type || !start_date || !end_date) {
    return res.status(400).json({ error: 'Leave type, start date, and end date are required' });
  }

  try {
    const sapCode = reverseMapAbsenceType(leave_type);
    const fullDayVal = duration === 'Full-Day' ? 'X' : '';
    const absDays = duration === 'Full-Day' ? 1 : 0.5;
    const truncatedReason = (reason || '').toString().slice(0, 6);

    const query = `
      INSERT INTO absence (
        personnel_number, att_absence_type, start_date, end_date, start_time, end_time, 
        full_day, att_abs_days, absence_hours, desc_of_illness, lock_indicator, changed_on, changed_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'P', NOW(), ?)
    `;
    const [result] = await pool.query(query, [
      employeeId, sapCode, start_date, end_date, start_time || '09:00:00', end_time || '17:30:00',
      fullDayVal, absDays, absence_hours || (absDays * 8), truncatedReason, req.user.employee_number
    ]);

    res.status(201).json({
      message: 'Leave application submitted successfully',
      leaveId: result.insertId
    });
  } catch (error) {
    console.error('[Apply Leave Error]', error.message);
    res.status(500).json({ error: 'Failed to submit leave request', message: error.message });
  }
});

/**
 * @route   DELETE /api/leaves/:id
 * @desc    Cancel a pending leave application
 * @access  Private (JWT Token Required)
 */
router.delete('/leaves/:id', authenticateToken, async (req, res) => {
  const leaveId = req.params.id;
  const employeeId = req.user.employee_number;

  try {
    const selectQuery = `SELECT * FROM absence WHERE id = ?`;
    const [rows] = await pool.query(selectQuery, [leaveId]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Leave request not found' });
    }

    const leave = rows[0];
    if (leave.personnel_number.toString() !== employeeId.toString()) {
      return res.status(403).json({ error: 'Forbidden: You can only delete your own requests' });
    }

    const deleteQuery = `DELETE FROM absence WHERE id = ?`;
    await pool.query(deleteQuery, [leaveId]);

    res.json({ message: 'Leave request cancelled successfully' });
  } catch (error) {
    console.error('[Cancel Leave Error]', error.message);
    res.status(500).json({ error: 'Failed to cancel leave request', message: error.message });
  }
});

// ==========================================
// Leave Balance APIs
// ==========================================

/**
 * @route   GET /api/leave-balances
 * @desc    Fetch leave quota balances for an employee
 * @access  Private (JWT Token Required)
 */
router.get('/leave-balances', authenticateToken, async (req, res) => {
  const employeeId = req.query.employee_id || req.user.employee_number;
  try {
    const query = `SELECT * FROM leave_quota WHERE personnel_number = ? ORDER BY deduction_to DESC`;
    const [rows] = await pool.query(query, [employeeId]);
    
    const balances = rows.map(row => {
      const entitlement = parseFloat(row.quota_number || 0);
      const deduction = parseFloat(row.quota_deduction || 0);
      return {
        timeAccount: mapAbsenceType(row.absence_quota_type),
        deductionFrom: row.deduction_from,
        deductionTo: row.deduction_to,
        entitlement,
        entitlementMinusPlanned: entitlement - deduction
      };
    });

    res.json(balances);
  } catch (error) {
    console.error('[Get Balances Error]', error.message);
    res.status(500).json({ error: 'Failed to fetch leave balances', message: error.message });
  }
});

// ==========================================
// Tour/Travel Management APIs
// ==========================================

/**
 * @route   GET /api/tours
 * @desc    Fetch travel requests for an employee
 * @access  Private (JWT Token Required)
 */
router.get('/tours', authenticateToken, async (req, res) => {
  const employeeId = req.query.employee_id || req.user.employee_number;
  try {
    const query = `SELECT * FROM travel WHERE personnel_number = ? ORDER BY beginning_date_of_trip_segment DESC`;
    const [rows] = await pool.query(query, [employeeId]);
    
    const tours = rows.map(row => {
      let status = 'Approved';
      if (row.planning_status === '1') status = 'Pending';
      else if (row.planning_status === '3') status = 'Rejected';
      else if (row.planning_status === '2') status = 'Approved';

      return {
        id: row.id.toString(),
        employeeId: row.personnel_number,
        tourType: row.trip_activity_type || 'Official Tour',
        destination: row.trip_destination,
        startDate: row.beginning_date_of_trip_segment,
        endDate: row.end_date_of_trip_segment,
        travelPurpose: row.reason_for_trip,
        transportMode: row.depart_res_workplace || 'Train',
        status,
        appliedOn: row.changed_on || row.beginning_date_of_trip_segment,
        approvedOn: row.changed_on
      };
    });

    res.json(tours);
  } catch (error) {
    console.error('[Get Tours Error]', error.message);
    res.status(500).json({ error: 'Failed to fetch tour requests', message: error.message });
  }
});

/**
 * @route   POST /api/tours
 * @desc    Submit a new travel segment request
 * @access  Private (JWT Token Required)
 */
router.post('/tours', authenticateToken, async (req, res) => {
  const { destination, start_date, end_date, travel_purpose, transport_mode, tour_type } = req.body;
  const employeeId = req.user.employee_number;

  if (!destination || !start_date || !end_date) {
    return res.status(400).json({ error: 'Destination, start date, and end date are required' });
  }

  try {
    const query = `
      INSERT INTO travel (
        personnel_number, trip_destination, beginning_date_of_trip_segment, end_date_of_trip_segment, 
        reason_for_trip, depart_res_workplace, trip_activity_type, planning_status, changed_on, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, '1', NOW(), ?)
    `;
    const [result] = await pool.query(query, [
      employeeId, destination, start_date, end_date, travel_purpose || '',
      transport_mode || 'Train', tour_type || 'Official Tour', req.user.employee_number
    ]);

    res.status(201).json({
      message: 'Tour request submitted successfully',
      tourId: result.insertId
    });
  } catch (error) {
    console.error('[Apply Tour Error]', error.message);
    res.status(500).json({ error: 'Failed to submit tour request', message: error.message });
  }
});

/**
 * @route   DELETE /api/tours/:id
 * @desc    Cancel a pending travel request
 * @access  Private (JWT Token Required)
 */
router.delete('/tours/:id', authenticateToken, async (req, res) => {
  const tourId = req.params.id;
  const employeeId = req.user.employee_number;

  try {
    const selectQuery = `SELECT * FROM travel WHERE id = ?`;
    const [rows] = await pool.query(selectQuery, [tourId]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Tour request not found' });
    }

    const tour = rows[0];
    if (tour.personnel_number.toString() !== employeeId.toString()) {
      return res.status(403).json({ error: 'Forbidden: You can only delete your own requests' });
    }

    const deleteQuery = `DELETE FROM travel WHERE id = ?`;
    await pool.query(deleteQuery, [tourId]);

    res.json({ message: 'Tour request cancelled successfully' });
  } catch (error) {
    console.error('[Cancel Tour Error]', error.message);
    res.status(500).json({ error: 'Failed to cancel tour request', message: error.message });
  }
});

// ==========================================
// Holiday Calendar APIs
// ==========================================

/**
 * @route   GET /api/holidays
 * @desc    Fetch holidays list for the calendar
 * @access  Public
 */
router.get('/holidays', async (req, res) => {
  try {
    const query = `
      SELECT MIN(id) as id, MIN(personnel_area) as personnel_area, MIN(personnel_subarea) as personnel_subarea, optional_holiday_date, description, MIN(start_date) as start_date, MIN(end_date) as end_date 
      FROM zhcm_opt_holiday 
      WHERE optional_holiday_date IS NOT NULL AND description IS NOT NULL
      GROUP BY optional_holiday_date, description 
      ORDER BY optional_holiday_date ASC
    `;
    const [rows] = await pool.query(query);
    
    const holidays = rows.map(row => {
      const subArea = (row.personnel_subarea || '').toUpperCase();
      const desc = (row.description || '').toUpperCase();
      
      let type = 'Optional';
      
      // List of standard compulsory/national holiday keywords
      const compulsoryKeywords = [
        'REPUBLIC', 'INDEPENDENCE', 'GANDHI', 'DIWALI', 'DEEPAVALI', 'LAXMI', 
        'HOLI', 'CHRISTMAS', 'X-MAS', 'XMAS', 'GOOD FRIDAY', 'RAM NAVAMI', 'RAM NAVMI', 
        'BUDH PURNIMA', 'BUDHA PURNIMA', 'GURU NANAK', 'ID-UL', 'EID-UL', 'EID AL-FITR', 
        'BAKRID', 'RAMZAN', 'MAHAVIR', 'DUSSEHRA', 'DASA HARA', 'VIJAYA', 'MUHARRAM', 
        'MOHARRAM', 'MILAD', 'JANMASHTAMI', 'JANMASTAMI', 'KRISHNA JAYANTI', 'KRUSHNA JAYANTI'
      ];
      
      const isCompulsory = compulsoryKeywords.some(keyword => desc.includes(keyword));
      
      if (isCompulsory) {
        type = 'National';
      } else if (subArea.includes('NATIONAL') || subArea.includes('PUBLIC')) {
        type = 'National';
      } else if (subArea.includes('REGIONAL')) {
        type = 'Regional';
      }

      return {
        id: row.id.toString(),
        name: row.description,
        date: row.optional_holiday_date,
        type,
        isNational: type === 'National'
      };
    });

    res.json(holidays);
  } catch (error) {
    console.error('[Get Holidays Error]', error.message);
    res.status(500).json({ error: 'Failed to fetch holidays calendar', message: error.message });
  }
});

// ==========================================
// Profile & Employees Management APIs
// ==========================================

function formatDate(date) {
  if (!date) return 'N/A';
  const d = new Date(date);
  if (isNaN(d.getTime())) return 'N/A';
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}-${month}-${year}`;
}

function mapEmployeeRow(row) {
  const nominees = [];
  if (row.nomination_gratuity) {
    nominees.push({ name: row.nomination_gratuity, relationship: row.nomination_gratuity_rel || 'WIFE', type: 'Gratuity' });
  }
  if (row.nomination_pf) {
    nominees.push({ name: row.nomination_pf, relationship: row.nomination_pf_relation || 'WIFE', type: 'PF' });
  }
  if (row.nomination_pension) {
    nominees.push({ name: row.nomination_pension, relationship: row.nomination_pension_rel || 'WIFE', type: 'Pension' });
  }

  const serviceHistory = [];
  if (row.date_of_appointment) {
    serviceHistory.push({
      date: formatDate(row.date_of_appointment),
      action: 'Appointment',
      reason: row.hire_action_reason || 'Regular Joining'
    });
  }
  if (row.latest_promotion_dt) {
    serviceHistory.push({
      date: formatDate(row.latest_promotion_dt),
      action: 'Promotion',
      reason: 'Regular Promotion'
    });
  }

  return {
    id: row.employee_number.toString(),
    employeeId: row.employee_number.toString(),
    name: row.employee_name,
    fatherSpouseName: row.family_members_father || row.family_members_spouse || 'N/A',
    designation: row.position_name || 'Employee',
    department: row.department || 'N/A',
    presentGrade: row.employee_subgroup_text || row.employee_subgroup || 'N/A',
    dateOfBirth: formatDate(row.date_of_birth),
    joinDate: formatDate(row.date_of_appointment),
    lastPromotionDate: formatDate(row.latest_promotion_dt),
    appointmentType: row.hire_action_reason || 'Regular',
    category: row.caste || 'GEN',
    bloodGroup: row.blood_group || 'O+',
    gender: row.gender || 'Male',
    maritalStatus: row.marital_status || 'Single',
    basicSalary: parseFloat(row.basic_pay || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 }),
    presentPlaceOfPosting: row.personnel_subarea_text || 'Head Office',
    presentPostingDate: formatDate(row.act_doj_on_promt_dt),
    retirementDate: formatDate(row.date_of_retirement),
    mobileNumber: row.mobile_number || 'N/A',
    email: row.email_id || 'N/A',
    uanNo: row.uan || 'N/A',
    panNo: row.pan_number || 'N/A',
    aadhaarNo: row.aadhar_number || 'N/A',
    pranNo: row.praan_no || 'N/A',
    pfNo: row.employee_pf_number || 'N/A',
    pensionNo: row.pension_id || 'N/A',
    reportingOfficer: (row.reporting_officer || 'N/A').toString(),
    reportingOfficer1: (row.reporting_officer_1 || 'N/A').toString(),
    address: row.permanent_address || 'N/A',
    emergencyContact: row.emergency_address || row.mobile_number || 'N/A',
    nominees,
    serviceHistory
  };
}

/**
 * @route   GET /api/profile
 * @desc    Get detailed profile of the logged-in employee
 * @access  Private (JWT Token Required)
 */
router.get('/profile', authenticateToken, async (req, res) => {
  const employeeId = req.query.employee_id || req.user.employee_number;
  try {
    const query = `
      SELECT m.*, a.reporting_officer, a.reporting_officer_1 
      FROM manpower m 
      LEFT JOIN zhcm_lr_t_agents_03072026 a ON m.employee_number = a.personnel_number 
      WHERE m.employee_number = ?
    `;
    const [rows] = await pool.query(query, [employeeId]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Profile not found' });
    }

    res.json(mapEmployeeRow(rows[0]));
  } catch (error) {
    console.error('[Get Profile Error]', error.message);
    res.status(500).json({ error: 'Failed to fetch employee profile', message: error.message });
  }
});

/**
 * @route   PUT /api/profile
 * @desc    Update editable profile info (mobile, address, emergencyContact)
 * @access  Private (JWT Token Required)
 */
router.put('/profile', authenticateToken, async (req, res) => {
  const { mobile_number, address, emergency_contact } = req.body;
  const employeeId = req.user.employee_number;

  try {
    const updateQuery = `
      UPDATE manpower 
      SET 
        mobile_number = COALESCE(?, mobile_number),
        permanent_address = COALESCE(?, permanent_address),
        emergency_address = COALESCE(?, emergency_address)
      WHERE employee_number = ?
    `;
    await pool.query(updateQuery, [mobile_number || null, address || null, emergency_contact || null, employeeId]);

    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    console.error('[Update Profile Error]', error.message);
    res.status(500).json({ error: 'Failed to update employee profile', message: error.message });
  }
});

/**
 * @route   GET /api/employees
 * @desc    Get complete list of all employees (mapped to EmployeeModel)
 * @access  Private (JWT Token Required)
 */
router.get('/employees', authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT m.*, a.reporting_officer, a.reporting_officer_1 
      FROM manpower m 
      LEFT JOIN zhcm_lr_t_agents_03072026 a ON m.employee_number = a.personnel_number
    `;
    const [rows] = await pool.query(query);
    
    const employees = rows.map(row => mapEmployeeRow(row));
    res.json(employees);
  } catch (error) {
    console.error('[Get Employees Error]', error.message);
    res.status(500).json({ error: 'Failed to fetch employees list', message: error.message });
  }
});

// ==========================================
// Dynamic Notifications API
// ==========================================

/**
 * @route   GET /api/notifications
 * @desc    Dynamically load employee notification activities from database logs
 * @access  Private (JWT Token Required)
 */
router.get('/notifications', authenticateToken, async (req, res) => {
  const employeeId = req.user.employee_number;
  try {
    const leavesQuery = `SELECT * FROM absence WHERE personnel_number = ? ORDER BY start_date DESC LIMIT 5`;
    const [leaves] = await pool.query(leavesQuery, [employeeId]);

    const toursQuery = `SELECT * FROM travel WHERE personnel_number = ? ORDER BY beginning_date_of_trip_segment DESC LIMIT 5`;
    const [tours] = await pool.query(toursQuery, [employeeId]);

    const notifications = [];

    leaves.forEach((row, index) => {
      let statusStr = 'has been approved';
      let typeStr = 'leave_approved';
      if (row.lock_indicator === 'P') {
        statusStr = 'is pending approval';
        typeStr = 'leave_pending';
      } else if (row.lock_indicator === 'R') {
        statusStr = 'has been rejected';
        typeStr = 'leave_rejected';
      }

      const formattedDate = new Date(row.start_date).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' });
      
      notifications.push({
        id: `leave_${row.id}`,
        title: row.lock_indicator === 'P' ? 'Leave Request Submitted' : (row.lock_indicator === 'R' ? 'Leave Request Rejected' : 'Leave Approved'),
        message: `Your ${mapAbsenceType(row.att_absence_type)} request for ${formattedDate} ${statusStr}.`,
        type: typeStr,
        timestamp: row.changed_on || new Date(),
        isRead: index >= 2
      });
    });

    tours.forEach((row, index) => {
      let statusStr = 'has been approved';
      let typeStr = 'tour_approved';
      if (row.planning_status === '1') {
        statusStr = 'is pending approval';
        typeStr = 'tour_pending';
      } else if (row.planning_status === '3') {
        statusStr = 'has been rejected';
        typeStr = 'tour_rejected';
      }

      notifications.push({
        id: `tour_${row.id}`,
        title: row.planning_status === '1' ? 'Tour Request Submitted' : (row.planning_status === '3' ? 'Tour Request Rejected' : 'Tour Approved'),
        message: `Your Official Tour request to ${row.trip_destination} ${statusStr}.`,
        type: typeStr,
        timestamp: row.changed_on || new Date(),
        isRead: index >= 2
      });
    });

    notifications.sort((a, b) => b.timestamp - a.timestamp);
    res.json(notifications);
  } catch (error) {
    console.error('[Get Notifications Error]', error.message);
    res.status(500).json({ error: 'Failed to fetch notifications', message: error.message });
  }
});

module.exports = router;
